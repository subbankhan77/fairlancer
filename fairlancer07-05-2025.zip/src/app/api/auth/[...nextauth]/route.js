import { handler } from "@/lib/auth";
export { handler as GET, handler as POST };