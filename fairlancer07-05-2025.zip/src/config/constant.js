export const ROLE_OPTIONS = [
    "Client",
    "Freelancer"
];

export const DEFAULT_AVATAR = "/images/default-avatar.jpg";