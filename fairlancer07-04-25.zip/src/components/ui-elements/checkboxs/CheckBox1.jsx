export default function CheckBox1() {
  return (
    <>
      <label className="custom_checkbox">
        Items
        <input type="checkbox" />
        <span className="checkmark" />
      </label>
    </>
  );
}
