export default function FreelancerSkill1() {
  return (
    <>
      <div className="sidebar-widget mb30 pb20 bdrs8">
        <h4 className="widget-title">My Skills</h4>
        <div className="tag-list mt30">
          <a>Figma</a>
          <a>Sketch</a>
          <a>HTML5</a>
          <a>Software Design</a>
          <a>Prototyping</a>
          <a>SaaS</a>
          <a>Design Writing</a>
        </div>
      </div>
    </>
  );
}
