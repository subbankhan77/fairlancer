
import Invoice from "@/components/section/Invoice";

export const metadata = {
  title: "Fairlancer - Freelance Marketplace React/Next Js Template | Invoices",
};

export default function page() {
  return (
    <>
    
      <Invoice />
    </>
  );
}
