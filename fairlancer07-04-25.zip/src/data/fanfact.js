export const funfactsData = [
  { id: 1, value: 834, label: "Total Freelancer" },
  { id: 2, value: 732, label: "Positive Review" },
  { id: 3, value: 236, label: "Projects Completed" },
];

export const funfactsData2 = [
  "Last Education of Bachelor Degree",
  "More Than 15 Years Experience",
  "12 Education Award Winning",
];
